package com.nextcart.nextcart.product_module.product_base;


import com.nextcart.nextcart.brand_module.entity.Brand;
import com.nextcart.nextcart.brand_module.repository.BrandRepository;
import com.nextcart.nextcart.category_module.entity.Category;
import com.nextcart.nextcart.category_module.repository.CategoryRepository;
import com.nextcart.nextcart.inventory_module.InventoryRepository;
import com.nextcart.nextcart.product_module.productPrice.ProductVariantPriceEntity;
import com.nextcart.nextcart.product_module.productPrice.ProductVariantPriceRepository;
import com.nextcart.nextcart.product_module.productSpecification.ProductSpecificationRepository;
import com.nextcart.nextcart.product_module.productVariant.ProductVariantRepository;
import com.nextcart.nextcart.product_module.product_base.dto.ProductCreateRequest;
import com.nextcart.nextcart.product_module.product_base.dto.ProductDetailsResponse;
import com.nextcart.nextcart.product_module.product_base.dto.ProductResponse;
import com.nextcart.nextcart.product_module.variantAttribute.VariantAttributeRepository;
import com.nextcart.nextcart.subcategory_module.entity.SubCategory;
import com.nextcart.nextcart.subcategory_module.repository.SubCategoryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Transactional
public class ProductServiceImpl implements ProductService {

    private final ProductRepository productRepository;
    private final ProductMapper productMapper;

    private final CategoryRepository categoryRepository;
    private final SubCategoryRepository subCategoryRepository;
    private final BrandRepository brandRepository;

    private final ProductVariantRepository productVariantRepository;

    private final ProductVariantPriceRepository productVariantPriceRepository;
    private final VariantAttributeRepository variantAttributeRepository;
    private final InventoryRepository inventoryRepository;

    private final ProductSpecificationRepository productSpecificationRepository;

    public ProductServiceImpl(ProductRepository productRepository, ProductMapper productMapper, CategoryRepository categoryRepository, SubCategoryRepository subCategoryRepository, BrandRepository brandRepository, ProductVariantRepository productVariantRepository, ProductVariantPriceRepository productVariantPriceRepository, VariantAttributeRepository variantAttributeRepository, InventoryRepository inventoryRepository, ProductSpecificationRepository productSpecificationRepository) {
        this.productRepository = productRepository;
        this.productMapper = productMapper;
        this.categoryRepository = categoryRepository;
        this.subCategoryRepository = subCategoryRepository;
        this.brandRepository = brandRepository;
        this.productVariantRepository = productVariantRepository;
        this.productVariantPriceRepository = productVariantPriceRepository;
        this.variantAttributeRepository = variantAttributeRepository;
        this.inventoryRepository = inventoryRepository;
        this.productSpecificationRepository = productSpecificationRepository;
    }

    /*
     * Add your existing Information/Image repositories or services here
     * after confirming their actual mapper/API.
     */

    // =========================================================
    // CREATE
    // =========================================================

    @Override
    public ProductResponse createProduct(ProductCreateRequest request) {

        validateSlugForCreate(request.getSlug());

        Category category =
                getActiveCategory(request.getCategoryId());

        SubCategory subCategory =
                getActiveSubCategory(request.getSubCategoryId());

        validateSubCategoryBelongsToCategory(
                subCategory,
                category
        );

        Brand brand =
                getActiveBrand(request.getBrandId());

        ProductEntity product =
                productMapper.toEntity(request);

        product.setCategory(category);
        product.setSubCategory(subCategory);
        product.setBrand(brand);

        ProductEntity savedProduct =
                productRepository.save(product);

        return productMapper.toResponse(savedProduct);
    }

    // =========================================================
    // GET BY ID
    // =========================================================

    @Override
    @Transactional(readOnly = true)
    public ProductResponse getProductById(Long id) {

        ProductEntity product =
                getActiveProductById(id);

        return productMapper.toResponse(product);
    }

    // =========================================================
    // GET BY SLUG
    // =========================================================

    @Override
    @Transactional(readOnly = true)
    public ProductResponse getProductBySlug(String slug) {

        ProductEntity product =
                getActiveProductBySlug(slug);

        return productMapper.toResponse(product);
    }

    // =========================================================
    // COMPLETE DETAILS BY ID
    // =========================================================

    @Override
    @Transactional(readOnly = true)
    public ProductDetailsResponse getProductDetailsById(Long id) {

        ProductEntity product =
                getActiveProductById(id);

        return buildProductDetails(product);
    }

    // =========================================================
    // COMPLETE DETAILS BY SLUG
    // =========================================================

    @Override
    @Transactional(readOnly = true)
    public ProductDetailsResponse getProductDetailsBySlug(
            String slug) {

        ProductEntity product =
                getActiveProductBySlug(slug);

        return buildProductDetails(product);
    }

    // =========================================================
    // BUILD COMPLETE PRODUCT DETAILS
    // =========================================================

    private ProductDetailsResponse buildProductDetails(
            ProductEntity product) {

        Long productId = product.getId();

        /*
         * ---------------------------------------------------------
         * SPECIFICATIONS
         * ---------------------------------------------------------
         */

        List<ProductSpecificationResponse> specifications =
                productSpecificationRepository
                        .findByProductEntity_IdOrderBySpecificationNameAsc(
                                productId
                        )
                        .stream()
                        .map(this::toSpecificationResponse)
                        .toList();

        /*
         * ---------------------------------------------------------
         * ACTIVE VARIANTS
         * ---------------------------------------------------------
         */

        List<ProductVariantEntity> variants =
                productVariantRepository
                        .findByProductEntity_Id(productId)
                        .stream()
                        .filter(variant ->
                                variant.getStatus()
                                        == ProductVariantStatus.ACTIVE
                        )
                        .toList();

        /*
         * No variants is valid.
         *
         * Example:
         * A product can exist before variants are configured.
         */

        List<Long> variantIds =
                variants.stream()
                        .map(ProductVariantEntity::getId)
                        .toList();

        /*
         * ---------------------------------------------------------
         * BATCH LOAD ATTRIBUTES
         * ---------------------------------------------------------
         */

        Map<Long, List<VariantAttributeEntity>>
                attributesByVariantId =
                variantIds.isEmpty()
                        ? Collections.emptyMap()
                        : variantAttributeRepository
                        .findByVariantIdInOrderByAttributeNameAsc(
                                variantIds
                        )
                        .stream()
                        .collect(Collectors.groupingBy(
                                attribute ->
                                        attribute
                                                .getVariant()
                                                .getId()
                        ));

        /*
         * ---------------------------------------------------------
         * BATCH LOAD PRICES
         * ---------------------------------------------------------
         */

        Map<Long, ProductVariantPriceEntity>
                pricesByVariantId =
                variantIds.isEmpty()
                        ? Collections.emptyMap()
                        : productVariantPriceRepository
                        .findByProductVariantIdIn(
                                variantIds
                        )
                        .stream()
                        .collect(Collectors.toMap(
                                price ->
                                        price
                                                .getProductVariant()
                                                .getId(),
                                Function.identity(),
                                (first, second) -> first
                        ));

        /*
         * ---------------------------------------------------------
         * BATCH LOAD INVENTORY
         * ---------------------------------------------------------
         */

        Map<Long, InventoryEntity>
                inventoryByVariantId =
                variantIds.isEmpty()
                        ? Collections.emptyMap()
                        : inventoryRepository
                        .findByProductVariantIdIn(
                                variantIds
                        )
                        .stream()
                        .collect(Collectors.toMap(
                                inventory ->
                                        inventory
                                                .getProductVariant()
                                                .getId(),
                                Function.identity(),
                                (first, second) -> first
                        ));

        /*
         * ---------------------------------------------------------
         * BUILD VARIANT RESPONSES
         * ---------------------------------------------------------
         */

        List<ProductVariantResponse> variantResponses =
                variants.stream()
                        .map(variant -> {

                            Long variantId =
                                    variant.getId();

                            List<VariantAttributeResponse>
                                    attributes =
                                    attributesByVariantId
                                            .getOrDefault(
                                                    variantId,
                                                    Collections.emptyList()
                                            )
                                            .stream()
                                            .map(this::toAttributeResponse)
                                            .toList();

                            ProductVariantPriceResponse price =
                                    Optional.ofNullable(
                                                    pricesByVariantId
                                                            .get(variantId)
                                            )
                                            .map(this::toPriceResponse)
                                            .orElse(null);

                            InventoryResponse inventory =
                                    Optional.ofNullable(
                                                    inventoryByVariantId
                                                            .get(variantId)
                                            )
                                            .map(this::toInventoryResponse)
                                            .orElse(null);

                            return ProductVariantResponse.builder()
                                    .id(variantId)
                                    .productId(productId)
                                    .sku(variant.getSku())
                                    .status(variant.getStatus())
                                    .attributes(attributes)
                                    .price(price)
                                    .inventory(inventory)
                                    .build();
                        })
                        .toList();

        /*
         * ---------------------------------------------------------
         * FINAL PRODUCT DETAILS
         * ---------------------------------------------------------
         */

        return ProductDetailsResponse.builder()
                .id(product.getId())
                .name(product.getName())
                .slug(product.getSlug())
                .description(product.getDescription())
                .categoryId(product.getCategory().getId())
                .subCategoryId(product.getSubCategory().getId())
                .brandId(product.getBrand().getId())
                /*
                 * Information and images intentionally left connected
                 * to their own module mapper/service.
                 */
                .specifications(specifications)
                .variants(variantResponses)
                .build();
    }

    // =========================================================
    // SPECIFICATION MAPPING
    // =========================================================

    private ProductSpecificationResponse
    toSpecificationResponse(
            ProductSpecification specification) {

        return ProductSpecificationResponse.builder()
                .id(specification.getId())
                .productId(
                        specification
                                .getProductEntity()
                                .getId()
                )
                .specificationName(
                        specification.getSpecificationName()
                )
                .specificationValue(
                        specification.getSpecificationValue()
                )
                .build();
    }

    // =========================================================
    // ATTRIBUTE MAPPING
    // =========================================================

    private VariantAttributeResponse toAttributeResponse(
            VariantAttributeEntity attribute) {

        return VariantAttributeResponse.builder()
                .id(attribute.getId())
                .variantId(attribute.getVariant().getId())
                .attributeName(attribute.getAttributeName())
                .attributeValue(attribute.getAttributeValue())
                .build();
    }

    // =========================================================
    // PRICE MAPPING
    // =========================================================

    private ProductVariantPriceResponse toPriceResponse(
            ProductVariantPriceEntity price) {

        return ProductVariantPriceResponse.builder()
                .id(price.getId())
                .productVariantId(
                        price.getProductVariant().getId()
                )
                .mrp(price.getMrp())
                .sellingPrice(price.getSellingPrice())
                .currency(price.getCurrency())
                .build();
    }

    // =========================================================
    // INVENTORY MAPPING
    // =========================================================

    private InventoryResponse toInventoryResponse(
            InventoryEntity inventory) {

        return InventoryResponse.builder()
                .id(inventory.getId())
                .productVariantId(
                        inventory.getProductVariant().getId()
                )
                .sku(
                        inventory.getProductVariant().getSku()
                )
                .availableStock(
                        inventory.getAvailableStock()
                )
                .reservedStock(
                        inventory.getReservedStock()
                )
                .createdAt(
                        inventory.getCreatedAt()
                )
                .updatedAt(
                        inventory.getUpdatedAt()
                )
                .build();
    }

    // =========================================================
    // GET ALL
    // =========================================================

    @Override
    @Transactional(readOnly = true)
    public Page<ProductResponse> getAllProducts(
            Pageable pageable) {

        return productRepository
                .findAllByStatus(
                        ProductStatus.ACTIVE,
                        pageable
                )
                .map(productMapper::toResponse);
    }

    // =========================================================
    // GET BY CATEGORY
    // =========================================================

    @Override
    @Transactional(readOnly = true)
    public Page<ProductResponse> getProductsByCategory(
            Long categoryId,
            Pageable pageable) {

        getActiveCategory(categoryId);

        return productRepository
                .findAllByCategoryIdAndStatus(
                        categoryId,
                        ProductStatus.ACTIVE,
                        pageable
                )
                .map(productMapper::toResponse);
    }

    // =========================================================
    // GET BY SUBCATEGORY
    // =========================================================

    @Override
    @Transactional(readOnly = true)
    public Page<ProductResponse> getProductsBySubCategory(
            Long subCategoryId,
            Pageable pageable) {

        getActiveSubCategory(subCategoryId);

        return productRepository
                .findAllBySubCategoryIdAndStatus(
                        subCategoryId,
                        ProductStatus.ACTIVE,
                        pageable
                )
                .map(productMapper::toResponse);
    }

    // =========================================================
    // GET BY BRAND
    // =========================================================

    @Override
    @Transactional(readOnly = true)
    public Page<ProductResponse> getProductsByBrand(
            Long brandId,
            Pageable pageable) {

        getActiveBrand(brandId);

        return productRepository
                .findAllByBrandIdAndStatus(
                        brandId,
                        ProductStatus.ACTIVE,
                        pageable
                )
                .map(productMapper::toResponse);
    }

    // =========================================================
    // UPDATE
    // =========================================================

    @Override
    public ProductResponse updateProduct(
            Long id,
            ProductUpdateRequest request) {

        ProductEntity product =
                productRepository.findById(id)
                        .orElseThrow(() ->
                                new ProductNotFoundException(
                                        "Product not found with id: " + id
                                )
                        );

        validateSlugForUpdate(
                request.getSlug(),
                id
        );

        Category category =
                getActiveCategory(request.getCategoryId());

        SubCategory subCategory =
                getActiveSubCategory(request.getSubCategoryId());

        validateSubCategoryBelongsToCategory(
                subCategory,
                category
        );

        Brand brand =
                getActiveBrand(request.getBrandId());

        productMapper.updateEntity(
                request,
                product
        );

        product.setCategory(category);
        product.setSubCategory(subCategory);
        product.setBrand(brand);

        ProductEntity updated =
                productRepository.save(product);

        return productMapper.toResponse(updated);
    }

    // =========================================================
    // DEACTIVATE
    // =========================================================

    @Override
    public void deactivateProduct(Long id) {

        ProductEntity product =
                productRepository.findById(id)
                        .orElseThrow(() ->
                                new ProductNotFoundException(
                                        "Product not found with id: " + id
                                )
                        );

        if (product.getStatus()
                == ProductStatus.INACTIVE) {

            throw new ProductValidationException(
                    "Product is already inactive"
            );
        }

        product.setStatus(ProductStatus.INACTIVE);
    }

    // =========================================================
    // RESTORE
    // =========================================================

    @Override
    public ProductResponse restoreProduct(Long id) {

        ProductEntity product =
                productRepository.findById(id)
                        .orElseThrow(() ->
                                new ProductNotFoundException(
                                        "Product not found with id: " + id
                                )
                        );

        if (product.getStatus()
                == ProductStatus.ACTIVE) {

            throw new ProductValidationException(
                    "Product is already active"
            );
        }

        validateRestoreDependencies(product);

        product.setStatus(ProductStatus.ACTIVE);

        return productMapper.toResponse(product);
    }

    // =========================================================
    // PRODUCT LOOKUPS
    // =========================================================

    private ProductEntity getActiveProductById(Long id) {

        if (id == null) {
            throw new ProductValidationException(
                    "Product id is required"
            );
        }

        return productRepository
                .findByIdAndStatus(
                        id,
                        ProductStatus.ACTIVE
                )
                .orElseThrow(() ->
                        new ProductNotFoundException(
                                "Product not found with id: " + id
                        )
                );
    }

    private ProductEntity getActiveProductBySlug(
            String slug) {

        if (slug == null || slug.isBlank()) {
            throw new ProductValidationException(
                    "Product slug is required"
            );
        }

        String normalizedSlug =
                slug.trim();

        return productRepository
                .findBySlugIgnoreCaseAndStatus(
                        normalizedSlug,
                        ProductStatus.ACTIVE
                )
                .orElseThrow(() ->
                        new ProductNotFoundException(
                                "Product not found with slug: "
                                        + normalizedSlug
                        )
                );
    }

    // =========================================================
    // VALIDATE CREATE SLUG
    // =========================================================

    private void validateSlugForCreate(
            String slug) {

        if (slug == null || slug.isBlank()) {
            throw new ProductValidationException(
                    "Product slug is required"
            );
        }

        if (productRepository
                .existsBySlugIgnoreCase(slug.trim())) {

            throw new ProductAlreadyExistsException(
                    "Product slug already exists: "
                            + slug
            );
        }
    }

    // =========================================================
    // VALIDATE UPDATE SLUG
    // =========================================================

    private void validateSlugForUpdate(
            String slug,
            Long productId) {

        if (slug == null || slug.isBlank()) {
            throw new ProductValidationException(
                    "Product slug is required"
            );
        }

        if (productRepository
                .existsBySlugIgnoreCaseAndIdNot(
                        slug.trim(),
                        productId
                )) {

            throw new ProductAlreadyExistsException(
                    "Product slug already exists: "
                            + slug
            );
        }
    }

    // =========================================================
    // CATEGORY
    // =========================================================

    private Category getActiveCategory(
            Long categoryId) {

        return categoryRepository
                .findByIdAndStatus(
                        categoryId,
                        CategoryStatus.ACTIVE
                )
                .orElseThrow(() ->
                        new ProductValidationException(
                                "Active category not found with id: "
                                        + categoryId
                        )
                );
    }

    // =========================================================
    // SUBCATEGORY
    // =========================================================

    private SubCategory getActiveSubCategory(
            Long subCategoryId) {

        return subCategoryRepository
                .findByIdAndStatus(
                        subCategoryId,
                        SubCategoryStatus.ACTIVE
                )
                .orElseThrow(() ->
                        new ProductValidationException(
                                "Active subcategory not found with id: "
                                        + subCategoryId
                        )
                );
    }

    // =========================================================
    // BRAND
    // =========================================================

    private Brand getActiveBrand(
            Long brandId) {

        return brandRepository
                .findByIdAndStatus(
                        brandId,
                        BrandStatus.ACTIVE
                )
                .orElseThrow(() ->
                        new ProductValidationException(
                                "Active brand not found with id: "
                                        + brandId
                        )
                );
    }

    // =========================================================
    // CATEGORY / SUBCATEGORY VALIDATION
    // =========================================================

    private void validateSubCategoryBelongsToCategory(
            SubCategory subCategory,
            Category category) {

        if (subCategory.getCategory() == null
                || subCategory.getCategory().getId() == null
                || !subCategory.getCategory()
                .getId()
                .equals(category.getId())) {

            throw new ProductValidationException(
                    "SubCategory does not belong to the selected category"
            );
        }
    }

    // =========================================================
    // RESTORE DEPENDENCIES
    // =========================================================

    private void validateRestoreDependencies(
            ProductEntity product) {

        getActiveCategory(
                product.getCategory().getId()
        );

        getActiveSubCategory(
                product.getSubCategory().getId()
        );

        getActiveBrand(
                product.getBrand().getId()
        );

        validateSubCategoryBelongsToCategory(
                product.getSubCategory(),
                product.getCategory()
        );
    }
}class ProductServiceImpl implements ProductService {

    private final ProductRepository productRepository;
    private final ProductMapper productMapper;

    private final CategoryRepository categoryRepository;
    private final SubCategoryRepository subCategoryRepository;
    private final BrandRepository brandRepository;

    private final ProductVariantRepository productVariantRepository;


    // =========================================================
    // CREATE PRODUCT
    // =========================================================

    @Override
    public ProductResponse createProduct(
            ProductCreateRequest request) {

        validateSlugForCreate(
                request.getSlug()
        );

        Category category =
                getActiveCategory(
                        request.getCategoryId()
                );

        SubCategory subCategory =
                getActiveSubCategory(
                        request.getSubCategoryId()
                );

        validateSubCategoryBelongsToCategory(
                subCategory,
                category
        );

        Brand brand =
                getActiveBrand(
                        request.getBrandId()
                );

        ProductEntity product =
                productMapper.toEntity(request);

        product.setCategory(category);
        product.setSubCategory(subCategory);
        product.setBrand(brand);

        ProductEntity savedProduct =
                productRepository.save(product);

        return productMapper.toResponse(
                savedProduct
        );
    }


    // =========================================================
    // GET PRODUCT BY ID
    // =========================================================

    @Override
    @Transactional(readOnly = true)
    public ProductResponse getProductById(
            Long id) {

        ProductEntity productEntity =
                productRepository.findByIdAndStatus(
                                id,
                                ProductStatus.ACTIVE
                        )
                        .orElseThrow(() ->
                                new ProductNotFoundException(
                                        "Product not found with id: "
                                                + id
                                )
                        );

        return productMapper.toResponse(
                productEntity
        );
    }


    // =========================================================
    // GET PRODUCT BY SLUG
    // =========================================================

    @Override
    @Transactional(readOnly = true)
    public ProductResponse getProductBySlug(
            String slug) {

        ProductEntity productEntity =
                productRepository
                        .findBySlugIgnoreCaseAndStatus(
                                slug,
                                ProductStatus.ACTIVE
                        )
                        .orElseThrow(() ->
                                new ProductNotFoundException(
                                        "Product not found with slug: "
                                                + slug
                                )
                        );

        return productMapper.toResponse(
                productEntity
        );
    }


    // =========================================================
    // GET COMPLETE PRODUCT DETAILS
    // =========================================================

    @Override
    @Transactional(readOnly = true)
    public ProductDetailsResponse getProductDetailsById(
            Long id) {

        ProductEntity productEntity =
                productRepository.findByIdAndStatus(
                                id,
                                ProductStatus.ACTIVE
                        )
                        .orElseThrow(() ->
                                new ProductNotFoundException(
                                        "Product not found with id: "
                                                + id
                                )
                        );

        /*
         * IMPORTANT:
         *
         * ProductVariantEntity contains:
         *
         *     productEntity
         *
         * Therefore the repository method is:
         *
         *     findByProductEntity_Id(...)
         *
         * NOT:
         *
         *     findByProductId(...)
         */
        List<ProductVariantEntity> variants =
                productVariantRepository
                        .findByProductEntity_Id(id);


        /*
         * Map product variants.
         *
         * Inventory mapping is intentionally not performed here
         * until the actual InventoryEntity relationship is confirmed.
         */
        List<ProductVariantResponse> variantResponses =
                variants.stream()
                        .map(variant ->
                                ProductVariantResponse
                                        .builder()
                                        .id(
                                                variant.getId()
                                        )
                                        .productId(
                                                productEntity.getId()
                                        )
                                        .sku(
                                                variant.getSku()
                                        )
                                        .status(
                                                variant.getStatus()
                                        )
                                        .build()
                        )
                        .toList();


        return ProductDetailsResponse
                .builder()
                .id(
                        productEntity.getId()
                )
                .name(
                        productEntity.getName()
                )
                .slug(
                        productEntity.getSlug()
                )
                .description(
                        productEntity.getDescription()
                )
                .variants(
                        variantResponses
                )
                .build();
    }


    // =========================================================
    // GET ALL PRODUCTS
    // =========================================================

    @Override
    @Transactional(readOnly = true)
    public Page<ProductResponse> getAllProducts(
            Pageable pageable) {

        return productRepository
                .findAllByStatus(
                        ProductStatus.ACTIVE,
                        pageable
                )
                .map(productMapper::toResponse);
    }


    // =========================================================
    // GET PRODUCTS BY CATEGORY
    // =========================================================

    @Override
    @Transactional(readOnly = true)
    public Page<ProductResponse> getProductsByCategory(
            Long categoryId,
            Pageable pageable) {

        getActiveCategory(
                categoryId
        );

        return productRepository
                .findAllByCategoryIdAndStatus(
                        categoryId,
                        ProductStatus.ACTIVE,
                        pageable
                )
                .map(productMapper::toResponse);
    }


    // =========================================================
    // GET PRODUCTS BY SUBCATEGORY
    // =========================================================

    @Override
    @Transactional(readOnly = true)
    public Page<ProductResponse> getProductsBySubCategory(
            Long subCategoryId,
            Pageable pageable) {

        getActiveSubCategory(
                subCategoryId
        );

        return productRepository
                .findAllBySubCategoryIdAndStatus(
                        subCategoryId,
                        ProductStatus.ACTIVE,
                        pageable
                )
                .map(productMapper::toResponse);
    }


    // =========================================================
    // GET PRODUCTS BY BRAND
    // =========================================================

    @Override
    @Transactional(readOnly = true)
    public Page<ProductResponse> getProductsByBrand(
            Long brandId,
            Pageable pageable) {

        getActiveBrand(
                brandId
        );

        return productRepository
                .findAllByBrandIdAndStatus(
                        brandId,
                        ProductStatus.ACTIVE,
                        pageable
                )
                .map(productMapper::toResponse);
    }


    // =========================================================
    // UPDATE PRODUCT
    // =========================================================

    @Override
    public ProductResponse updateProduct(
            Long id,
            ProductUpdateRequest request) {

        ProductEntity productEntity =
                productRepository.findById(id)
                        .orElseThrow(() ->
                                new ProductNotFoundException(
                                        "Product not found with id: "
                                                + id
                                )
                        );

        validateSlugForUpdate(
                request.getSlug(),
                id
        );

        Category category =
                getActiveCategory(
                        request.getCategoryId()
                );

        SubCategory subCategory =
                getActiveSubCategory(
                        request.getSubCategoryId()
                );

        validateSubCategoryBelongsToCategory(
                subCategory,
                category
        );

        Brand brand =
                getActiveBrand(
                        request.getBrandId()
                );

        productMapper.updateEntity(
                request,
                productEntity
        );

        productEntity.setSlug(
                request.getSlug()
        );

        productEntity.setCategory(
                category
        );

        productEntity.setSubCategory(
                subCategory
        );

        productEntity.setBrand(
                brand
        );

        ProductEntity updatedProduct =
                productRepository.save(
                        productEntity
                );

        return productMapper.toResponse(
                updatedProduct
        );
    }


    // =========================================================
    // DEACTIVATE PRODUCT
    // =========================================================

    @Override
    public void deactivateProduct(
            Long id) {

        ProductEntity productEntity =
                productRepository.findById(id)
                        .orElseThrow(() ->
                                new ProductNotFoundException(
                                        "Product not found with id: "
                                                + id
                                )
                        );

        if (productEntity.getStatus()
                == ProductStatus.INACTIVE) {

            throw new ProductValidationException(
                    "Product is already inactive"
            );
        }

        productEntity.setStatus(
                ProductStatus.INACTIVE
        );

        productRepository.save(
                productEntity
        );
    }


    // =========================================================
    // RESTORE PRODUCT
    // =========================================================

    @Override
    public ProductResponse restoreProduct(
            Long id) {

        ProductEntity productEntity =
                productRepository.findById(id)
                        .orElseThrow(() ->
                                new ProductNotFoundException(
                                        "Product not found with id: "
                                                + id
                                )
                        );

        if (productEntity.getStatus()
                == ProductStatus.ACTIVE) {

            throw new ProductValidationException(
                    "Product is already active"
            );
        }

        validateRestoreDependencies(
                productEntity
        );

        productEntity.setStatus(
                ProductStatus.ACTIVE
        );

        ProductEntity restoredProduct =
                productRepository.save(
                        productEntity
                );

        return productMapper.toResponse(
                restoredProduct
        );
    }


    // =========================================================
    // VALIDATE CREATE SLUG
    // =========================================================

    private void validateSlugForCreate(
            String slug) {

        if (productRepository
                .existsBySlugIgnoreCase(slug)) {

            throw new ProductAlreadyExistsException(
                    "Product slug already exists: "
                            + slug
            );
        }
    }


    // =========================================================
    // VALIDATE UPDATE SLUG
    // =========================================================

    private void validateSlugForUpdate(
            String slug,
            Long productId) {

        if (productRepository
                .existsBySlugIgnoreCaseAndIdNot(
                        slug,
                        productId
                )) {

            throw new ProductAlreadyExistsException(
                    "Product slug already exists: "
                            + slug
            );
        }
    }


    // =========================================================
    // GET ACTIVE CATEGORY
    // =========================================================

    private Category getActiveCategory(
            Long categoryId) {

        return categoryRepository
                .findByIdAndStatus(
                        categoryId,
                        CategoryStatus.ACTIVE
                )
                .orElseThrow(() ->
                        new ProductValidationException(
                                "Active category not found with id: "
                                        + categoryId
                        )
                );
    }


    // =========================================================
    // GET ACTIVE SUBCATEGORY
    // =========================================================

    private SubCategory getActiveSubCategory(
            Long subCategoryId) {

        return subCategoryRepository
                .findByIdAndStatus(
                        subCategoryId,
                        SubCategoryStatus.ACTIVE
                )
                .orElseThrow(() ->
                        new ProductValidationException(
                                "Active subcategory not found with id: "
                                        + subCategoryId
                        )
                );
    }


    // =========================================================
    // GET ACTIVE BRAND
    // =========================================================

    private Brand getActiveBrand(
            Long brandId) {

        return brandRepository
                .findByIdAndStatus(
                        brandId,
                        BrandStatus.ACTIVE
                )
                .orElseThrow(() ->
                        new ProductValidationException(
                                "Active brand not found with id: "
                                        + brandId
                        )
                );
    }


    // =========================================================
    // VALIDATE CATEGORY / SUBCATEGORY
    // =========================================================

    private void validateSubCategoryBelongsToCategory(
            SubCategory subCategory,
            Category category) {

        if (subCategory.getCategory() == null
                || subCategory.getCategory().getId() == null
                || !subCategory.getCategory()
                .getId()
                .equals(category.getId())) {

            throw new ProductValidationException(
                    "SubCategory does not belong to the selected category"
            );
        }
    }


    // =========================================================
    // VALIDATE RESTORE DEPENDENCIES
    // =========================================================

    private void validateRestoreDependencies(
            ProductEntity productEntity) {

        getActiveCategory(
                productEntity
                        .getCategory()
                        .getId()
        );

        getActiveSubCategory(
                productEntity
                        .getSubCategory()
                        .getId()
        );

        getActiveBrand(
                productEntity
                        .getBrand()
                        .getId()
        );

        validateSubCategoryBelongsToCategory(
                productEntity.getSubCategory(),
                productEntity.getCategory()
        );
    }
}